function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
}
let emojis = ['♻️', '🍎', '🥤', '🗑️'];
let items = [];
let bins = [];
let score = 0;

function setup() {
  createCanvas(600, 400);
  
  // Definir os cestos de reciclagem
  bins.push({ x: 100, y: 350, w: 100, h: 50, type: 'reciclável' });
  bins.push({ x: 250, y: 350, w: 100, h: 50, type: 'orgânico' });
  bins.push({ x: 400, y: 350, w: 100, h: 50, type: 'lixo comum' });
  
  // Gerar itens para reciclagem
  for (let i = 0; i < 5; i++) {
    items.push(createItem());
  }
}

function draw() {
  background(240);
  
  // Desenhar os cestos
  for (let i = 0; i < bins.length; i++) {
    let bin = bins[i];
    fill(200);
    rect(bin.x, bin.y, bin.w, bin.h);
    textAlign(CENTER, CENTER);
    fill(0);
    textSize(16);
    text(bin.type, bin.x + bin.w / 2, bin.y + bin.h / 2);
  }
  
  // Atualizar e desenhar os itens
  for (let i = 0; i < items.length; i++) {
    let item = items[i];
    item.update();
    item.display();
  }

  // Exibir a pontuação
  fill(0);
  textSize(20);
  text('Pontuação: ' + score, width / 2, 30);
}

function createItem() {
  let emoji = random(emojis);
  let type;
  
  // Determinar o tipo de lixo de acordo com o emoji
  if (emoji === '♻️') type = 'reciclável';
  else if (emoji === '🍎') type = 'orgânico';
  else if (emoji === '🥤') type = 'reciclável';
  else if (emoji === '🗑️') type = 'lixo comum';

  return new Item(random(50, width - 50), random(50, height - 200), emoji, type);
}

class Item {
  constructor(x, y, emoji, type) {
    this.x = x;
    this.y = y;
    this.emoji = emoji;
    this.type = type;
    this.isDragging = false;
  }
  
  display() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
  
  update() {
    if (this.isDragging) {
      this.x = mouseX;
      this.y = mouseY;
    }
  }
  
  checkBin(bin) {
    if (this.x > bin.x && this.x < bin.x + bin.w && this.y > bin.y && this.y < bin.y + bin.h) {
      // Verificar se o item está sendo descartado no cesto correto
      if (this.type === bin.type) {
        score++;
        items.splice(items.indexOf(this), 1); // Remover item correto
        items.push(createItem()); // Gerar um novo item
      } else {
        // Se for descartado no cesto errado, apenas retornar à posição inicial
        this.x = random(50, width - 50);
        this.y = random(50, height - 200);
      }
    }
  }
}

function mousePressed() {
  // Verificar se o item foi clicado
  for (let i = 0; i < items.length; i++) {
    let item = items[i];
    if (dist(mouseX, mouseY, item.x, item.y) < 20) {
      item.isDragging = true;
    }
  }
}

function mouseReleased() {
  // Verificar onde o item foi solto
  for (let i = 0; i < items.length; i++) {
    let item = items[i];
    item.isDragging = false;
    for (let j = 0; j < bins.length; j++) {
      item.checkBin(bins[j]);
    }
  }
}
